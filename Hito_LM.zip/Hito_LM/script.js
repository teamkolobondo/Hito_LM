document.addEventListener('DOMContentLoaded', function() {
    const surveyResultsContainer = document.getElementById('survey-results');

    const filterCorreo = document.getElementById('filter-correo');
    const filterNombre = document.getElementById('filter-nombre');
    const filterHacesDeporte = document.getElementById('filter-haces-deporte');
    const filterQueDeporte = document.getElementById('filter-que-deporte');
    const filterCreeDeporte = document.getElementById('filter-cree-deporte');
    const filterGustariaDeporte = document.getElementById('filter-gustaria-deporte');

    let surveyData = [];

    function populateFilterOptions() {
        const uniqueEmails = [...new Set(surveyData.map(item => item.correo_electronico))];
        const uniqueNames = [...new Set(surveyData.map(item => item.nombre))];
        const uniqueDeportes = [...new Set(surveyData.map(item => item.que_deporte_haces))];
        const uniqueGustariaDeportes = [...new Set(surveyData.map(item => item['¿Deporte_que_te_gustaría_hacer?']))];

        uniqueEmails.forEach(email => {
            const option = document.createElement('option');
            option.value = email;
            option.textContent = email;
            filterCorreo.appendChild(option);
        });

        uniqueNames.forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            filterNombre.appendChild(option);
        });

        uniqueDeportes.forEach(deporte => {
            const option = document.createElement('option');
            option.value = deporte;
            option.textContent = deporte;
            filterQueDeporte.appendChild(option);
        });

        uniqueGustariaDeportes.forEach(deporte => {
            const option = document.createElement('option');
            option.value = deporte;
            option.textContent = deporte;
            filterGustariaDeporte.appendChild(option);
        });
    }

    function displaySurveyResults(filteredData) {
        surveyResultsContainer.innerHTML = '';

        filteredData.forEach(item => {
            const [fecha, hora] = item.marca_temporal.split(' ');

            const card = document.createElement('div');
            card.className = 'card mb-3';
            card.innerHTML = `
                <div class="card-body">
                    <h5 class="card-title">${item.nombre}</h5>
                    <p class="card-text"><strong>Fecha:</strong> ${fecha}</p>
                    <p class="card-text"><strong>Hora:</strong> ${hora}</p>
                    <p class="card-text"><strong>Correo Electrónico:</strong> ${item.correo_electronico}</p>
                    <p class="card-text"><strong>¿Haces algún deporte?:</strong> ${item.haces_algun_deporte}</p>
                    <p class="card-text"><strong>¿Qué deporte haces?:</strong> ${item.que_deporte_haces}</p>
                    <p class="card-text"><strong>¿Crees que el deporte es vital para llevar una vida saludable?:</strong> ${item.crees_que_el_deporte_es_vital_para_llevar_una_vida_saludable}</p>
                    <p class="card-text"><strong>¿Deporte que te gustaría hacer?:</strong> ${item['¿Deporte_que_te_gustaría_hacer?']}</p>
                </div>
            `;
            surveyResultsContainer.appendChild(card);
        });
    }

    function applyFilters() {
        const correo = filterCorreo.value;
        const nombre = filterNombre.value;
        const hacesDeporte = filterHacesDeporte.value;
        const queDeporte = filterQueDeporte.value;
        const creeDeporte = filterCreeDeporte.value;
        const gustariaDeporte = filterGustariaDeporte.value;

        const filteredData = surveyData.filter(item => {
            return (correo === '' || item.correo_electronico === correo) &&
                   (nombre === '' || item.nombre === nombre) &&
                   (hacesDeporte === '' || item.haces_algun_deporte === hacesDeporte) &&
                   (queDeporte === '' || item.que_deporte_haces === queDeporte) &&
                   (creeDeporte === '' || item.crees_que_el_deporte_es_vital_para_llevar_una_vida_saludable === creeDeporte) &&
                   (gustariaDeporte === '' || item['¿Deporte_que_te_gustaría_hacer?'] === gustariaDeporte);
        });

        displaySurveyResults(filteredData);
    }

    filterCorreo.addEventListener('change', applyFilters);
    filterNombre.addEventListener('change', applyFilters);
    filterHacesDeporte.addEventListener('change', applyFilters);
    filterQueDeporte.addEventListener('change', applyFilters);
    filterCreeDeporte.addEventListener('change', applyFilters);
    filterGustariaDeporte.addEventListener('change', applyFilters);

    fetch('https://api.jsonbin.io/v3/b/66474506e41b4d34e4f521ed', {
        headers: {
            'X-Master-Key': '$2b$10$afYtm2Dnb9cDWNUHf6IT7uwZWWKXgW9jsPa4dpADJnpkeV1nbxnZm' // Reemplaza con tu clave de API si es necesario
        }
    })
    .then(response => response.json())
    .then(data => {
        surveyData = data.record; // Ajuste según la estructura de la respuesta JSON de la API
        populateFilterOptions();
        applyFilters();
    })
    .catch(error => console.error('Error al cargar los datos:', error));
});
